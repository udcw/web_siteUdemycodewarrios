from django.db import models

# Create your models here.
class Recette(models.Model):
    titre = models.CharField(max_length=50)
    image = models.ImageField(upload_to="images",blank=True,null=True)
    liste_ingredients = models.TextField(blank=True)
    etapes = models.TextField(blank=True)
    auteur = models.CharField(max_length=50)
    date_publication = models.DateField( auto_now_add=False,auto_now=False)

    def __str__(self):
        return f'{self.titre}'
