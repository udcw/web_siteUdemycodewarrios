from django.shortcuts import render
from recette.models import Recette

# Create your views here.
def home(request):
    recettes = Recette.objects.all()
    return render(request, 'recette.html', context={'recettes':recettes})
